# parse_trisigma
This package parses PDF reports from Trisigma
