import os
import camelot
import pandas as pd
import locale
locale.setlocale(locale.LC_ALL, "nl_NL")
import datetime
import time
from string import ascii_uppercase as apc
import geopandas as gpd
import numpy as np
from shapely.geometry import Point
import matplotlib.pyplot as plt
from .isTimeFormat import isTimeFormat
from .check_trips import check_trips
from .DMS2DD import DMS2DD
from .str2latlon import str2latlon
from myUtils.mkch import mkch

class Parser:
    def __init__(self, out_path, reports_path) -> None:
        self.out_path = out_path
        self.reports_path = reports_path
        mkch(out_path)


    
    def parse(self):
        # Walk through all the folders and grab the file paths
        self.fnames = []
        self.dates = []
        for root, dirs, files in os.walk(self.reports_path):
            for f in files:
                if ".pdf" in f:
                    self.fnames.append(os.path.join(root, f))
                    self.dates.append(f)
        
        # Grab the date information from the filenames
        self.datetimes = []
        for d in self.dates:
            d = d.replace("Daily production Report - ", "").replace("DPR", "").replace(".pdf", "").replace("KA3", "").replace(" ", "").capitalize().replace("desember", "december")
            self.datetimes.append(datetime.datetime.strptime(d, "%d%B%Y").strftime("%Y-%m-%d"))

        self.df_tot = pd.DataFrame()
        for i in range(len(self.fnames)):
            f = self.fnames[i]
            ref_date = self.datetimes[i]
            print(ref_date)
            df = self._parse_pdf(f, ref_date)
            self.df_tot = pd.concat([self.df_tot, df])

        return self.df_tot





    def _parse_pdf(self, fname, ref_date):
        """
        Parse the data from the PDF file
        """
        df = camelot.read_pdf(fname)._tables[0].df
        df = self.clean_df(df, ref_date)
        return df


    def DMS2DD(self, DMS):
        angle = float(DMS.split("°")[0])
        tmp = DMS.split("°")[1]
        minute = float(tmp.split("'")[0])
        tmp = tmp.split("'")[1]
        second = float(tmp.split('"')[0].replace(",", "."))
        angle = angle + minute / 60 + second / 3600
        if tmp.split('"')[1] == "S" or tmp.split('"')[1] == "W":
            angle = angle * (-1)
        return angle
    
    def str2latlon(self, str):
        try:
            lat = DMS2DD(str.split("\n")[0].strip().replace('`', ''))
            lon = DMS2DD(str.split("\n")[1].strip().replace('`', ''))
            return [np.round(lat, 3), np.round(lon, 3)]
        except:
            return [np.nan, np.nan]
        
    def get_number(self, x):
        try:
            return x.replace(" mtr", "").replace(",", ".").replace(" m", "").replace("mtr", "")
        except:
            return np.nan

    def set_date(self, x, ref_date):
        try:
            ref_date = datetime.strptime(ref_date, "%Y-%m-%d")
            x = datetime.strptime(x, "%H:%M").time()
            return ref_date.combine(ref_date, x)
        except:
            return np.nan
        
    def m3(self, x):
        try:
            return float(x.replace(".", ""))
        except:
            return np.nan
        
    def clean_df(self, df, ref_date):
        df = df[[0, 2, 3, 5, 6, 7, 8, 10, 11, 13, 21, 23, 24, 25]]
        df.drop([0, 1, 2], axis=0, inplace=True)
        df.drop(range(15, len(df)+3), axis=0, inplace=True)
        df.reset_index(inplace=True)
        df.columns = ["Row", "Trip", "Start Dredging", "Finish Dredging", "Loaded Draft", "Dredging Coord", "Start Travelling", "Finish Travelling", "Start Dumping", "Finish Dumping", "Empty Draft", "Dumping Coord", "Hopper", "% Sediment", "Volume"]
        df.set_index("Row", inplace=True)
        df.replace("", np.nan, inplace=True)
        df.dropna(axis=0, how='all', inplace=True)

        df["Start Dredging"] = df["Start Dredging"].apply(self.set_date, args=[ref_date])
        df["Finish Dredging"] = df["Finish Dredging"].apply(self.set_date, args=[ref_date])
        df["Loaded Draft"] = df["Loaded Draft"].apply(self.get_number)
        df["Dredging Coord"] = df["Dredging Coord"].apply(self.str2latlon)
        df["Start Travelling"] = df["Start Travelling"].apply(self.set_date, args=[ref_date])
        df["Finish Travelling"] = df["Finish Travelling"].apply(self.set_date, args=[ref_date])
        df["Start Dumping"] = df["Start Dumping"].apply(self.set_date, args=[ref_date])
        df["Finish Dumping"] = df["Finish Dumping"].apply(self.set_date, args=[ref_date])
        df["Empty Draft"] = df["Empty Draft"].apply(self.get_number)
        df["Dumping Coord"] = df["Dumping Coord"].apply(self.str2latlon)
        df["Hopper"] = df["Hopper"].apply(self.m3)
        df["Volume"] = df["Volume"].apply(self.m3)

        return df